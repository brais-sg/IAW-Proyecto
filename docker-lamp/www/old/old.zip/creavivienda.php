<html lang="es">
<meta charset="UTF-8">
<head>
    <title>Subir archivo en PHP</title>
</head>
<body>
<?php
$link = mysqli_connect("db", "root", "test", "Inmobiliaria");
if(mysqli_connect_errno()){
    echo "<h1 style=\"color: red;\">Ha fallado la conexión a la base de datos</h1>";
} else {
    // Subimos la imagen primero
    

}


?>
</body>
</html>