<?php
session_start();

// Si la sesión no está iniciada (alguien acabó aquí sin pasar por el login, o expiró), lo redireccionamos a la página principal
if(!isset($_SESSION["user"])){
    header("Location: index.html", TRUE, 301);
    die();
}

// Mostramos el menú principal

echo "<div align=\"right\">";
echo "Hola <b>".$_SESSION["user"]."</b>";
echo " <a href=\"salir.php\">Pechar sesión</a>";
echo "</div>";
echo "<hr>";

$link = mysqli_connect("db", "root", "test", "frota");
if(mysqli_connect_errno()){
    echo "Ha fallado la conexión a la base de datos";
    die();

} else {    
    $select = "SELECT * FROM vehiculo_aluguer;";
    $query = mysqli_query($link, $select);
    
    if($query == false){
        echo "Por alguna extraña razón no se pueden mostrar los vehículos en alquiler, vuelve a intentarlo a ver si la siguiente vez funciona<br>";
        echo "Si no, F por la base de datos<br>";
    } else {

        echo "<h2>Vehículos disponibles para alugar:</h2>";
        echo "<table style=\"border: 1px solid black;\">";
        echo "<th>Modelo</th><th>Cantidade</th><th>Descrición</th><th>Marca</th><th>Prezo</th><th>Imaxe</th>";
        while($value = mysqli_fetch_array($query, MYSQLI_ASSOC)){
            echo "<tr>";
            foreach($value as $k => $v){
                echo "<td style=\"border: 1px solid black;\">$v</td>";
            }
            echo "</tr>";
        }
        echo "</table>";
    }
    mysqli_free_result($query);
}
?>