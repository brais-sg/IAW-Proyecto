<html>
<head>
    <title>Ejercicio 6 - Salarios</title>
</head>
<body>
<?php


$nome   = $_REQUEST["nome"];
$grupo  = $_REQUEST["grupo"];
$comida = $_REQUEST["comida"];

echo "Estos son os gustos de $nome: <br/>";
echo "A súa música preferida é $grupo e a súa comida preferida é a $comida <br/>";

?>
</body>

</html>