<?php
session_start();

// Si la sesión no está iniciada (alguien acabó aquí sin pasar por el login, o expiró), lo redireccionamos a la página principal
if(!isset($_SESSION["user"])){
    header("Location: index.html", TRUE, 301);
    die();
}

echo "<div align=\"right\">";
echo "Hola <b>".$_SESSION["user"]."</b>";
echo " <a href=\"salir.php\">Pechar sesión</a>";
echo "</div>";
echo "<hr>";
echo "<h2>Modificar os meus datos</h2>";

// Iniciar comunicación con la base de datos, obtenemos todos los datos y los mostramos en el respectivo campo de texto
// Submit actualizará las modificaciones
$link = mysqli_connect("db", "root", "test", "frota");
if(mysqli_connect_errno()){
    echo "Ha fallado la conexión a la base de datos";
} else {
    // Obtenemos los datos actuales
    $select = sprintf("SELECT * FROM usuario WHERE usuario='%s'", $_SESSION["user"]);
    $query  = mysqli_query($link, $select);

    if($query == false){
        echo "Non se puido obter información do usuario dado";
    } else {
        



    }



    mysqli_close($link);
}

?>